<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class order_details_model extends Model
{
    use HasFactory;

    public $timestamps = false;

    protected $table = 'order_details';

    protected $fillable = ['order_id', 'franchise_id', 'user_id', 'menu_category_id', 'menu_category_name', 'menu_quantity', 'total_menu_price', 'status', 'date', 'created_at', 'updated_at'];
}
